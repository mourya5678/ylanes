import React from 'react';

const CreatePoll = () => {
    return (
        <div>
            CreatePoll
        </div>
    )
};

export default CreatePoll;