import React from 'react';

const CreatePost = () => {
    return (
        <div>
            CreatePost
        </div>
    )
};

export default CreatePost;